<?php defined('CORE_DIR') || exit('入口错误'); ?>
<?php
echo 1;
